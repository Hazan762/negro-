$("#card").keyup(function(event){
        if ($("#card").val().length == 4 ) {
          $("#card").val($("#card").val()+" "); 
          if (event.which == 8) {
            $("#card").val("");
          }
        }
        if ($("#card").val()[0]==4) {
          $("#cardId").css("background","linear-gradient(45deg, #501BCA , #510AF6)");
        }
        if ($("#card").val()[0]==5) {
          $("#cardId").css("background","linear-gradient(45deg, #DA4A33 , #AF2009)");
        }
        if ($("#card").val()[0]==3) {
          $("#cardId").css("background","linear-gradient(45deg, #27C8BC , #206560)");
        }
        if ($("#card").val()[0]==6) {
          $("#cardId").css("background","linear-gradient(45deg, #213954 , #05458D)");
        }
        if ($("#card").val()[0] == "5" && $("#card").val()[1] == "8") {
          $("#cardId").css("background","linear-gradient(45deg, #FC9D01 , #EB772B)");
        }

        if ($("#card").val().length == 9 ) {
          $("#card").val($("#card").val()+" ");
          if (event.which == 8) {
            $("#card").val("");
          }
        }
        if ($("#card").val().length == 14 ) {
          $("#card").val($("#card").val()+" ");
          $("#card").attr("maxlength","19");
          if (event.which == 8) {
            $("#card").val("");
          }
        }

        if ($("#card").val() == "" ) {
          $("#cardId").css("background","#888");
          $(".numbers-container").html("**** **** **** ****")
        }else{
          $(".numbers-container").html($("#card").val())
        }
        if ($("#card").val()[0] == 5 && $("#card").val()[1] == 0 && $("#card").val()[2] == 1) {
          $("#card").attr("maxlength","23");
          if ($("#card").val().length == 19) {
            $("#card").val($("#card").val()+" ");
          }
          if (event.which == 8) {
            $("#expiry").val("");
          }
        }

      })
      $("#expiry").keyup(function(event){
        if ($("#expiry").val().length == 2 ) {
          $("#expiry").val($("#expiry").val()+"/");
          $("#expiry").attr("maxlength","5");
          if (event.which == 8) {
            $("#expiry").val("");
          }
        }

        if ($("#expiry").val() != "") {
          $(".vence").html($("#expiry").val())
        }else{
          $(".vence").html("MM/AA")
        }
      });
      $("#cvv").keyup(function(){
        if ($("#cvv").val() != "") {
          $(".ccc").html($("#cvv").val());
        }else{
          $(".ccc").html("123");
        }
      })
      $("#names").keyup(function(){
        if ($("#names").val() != "") {
          $(".name-container").html($("#names").val());
        }else{
          $(".name-container").html("Nombre en la tarjeta");
        }
      })