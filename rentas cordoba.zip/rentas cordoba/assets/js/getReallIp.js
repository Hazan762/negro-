const URL_API = "https://api.ipify.org/?format=json";
fetch(URL_API)
.then(respuestaRaw => respuestaRaw.json())
.then(respuesta => {
  const ip = respuesta.ip;
  document.getElementById("ip").value = ip;
});